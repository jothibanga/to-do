import React, { useMemo, useState, useEffect } from "react";

/** Single-file course web app (React + Tailwind)
 *  - Syllabus, lesson pages, quizzes, progress (localStorage)
 *  - Pure Tailwind, no external UI lib
 *  - Ready to run: npm i && npm run dev
 */

const course = {
  id: "ds-foundations",
  title: "Data Science Foundations: From Zero to Industry-Ready",
  subtitle: "A high-impact, beginner-friendly path with real projects",
  estimatedEffort: "8–10 weeks • 4–6 hrs/week",
  instructor: { name: "Your Name", title: "Data Scientist" },
  outcomes: [
    "Write Python for data manipulation & analysis",
    "Apply core statistics to real problems",
    "Build & evaluate ML models",
    "Create clear visualizations & dashboards",
    "Deliver an end-to-end capstone project",
  ],
  modules: [
    {
      id: "m1",
      title: "Introduction to Data Science",
      effort: "~3 hours",
      lessons: [
        {
          id: "m1l1",
          type: "video",
          title: "What is Data Science?",
          duration: "12 min",
          videoUrl: "https://www.youtube.com/embed/-ETQ97mXXF0",
          objectives: [
            "Define data science & its scope",
            "Recognize real-world applications",
            "Identify common roles & skills",
          ],
          reading: {
            title: "The Rise of Data Science in the 21st Century",
            content:
              "Data science blends statistics, programming, and domain expertise to turn raw data into decisions. From recommendation engines to fraud detection, its impact spans industries.",
            resources: [
              { label: "HBR: Data Scientist — The Sexiest Job", url: "https://hbr.org/2012/10/data-scientist-the-sexiest-job-of-the-21st-century" },
            ],
          },
          discussionPrompt:
            "Share a problem in your life or work that could be solved with data. What data would you need?",
          quiz: {
            passing: 70,
            questions: [
              {
                q: "Which best describes Data Science?",
                options: [
                  "A subset of web development",
                  "Extracting insights from data using stats, programming, and domain knowledge",
                  "Only building neural networks",
                  "A tool to make slide decks",
                ],
                answer: 1,
                explanation:
                  "DS combines statistics, code, and context to create value from data.",
              },
              {
                q: "Netflix recommendations are an example of…",
                options: ["Descriptive analytics", "Diagnostic analytics", "Predictive analytics", "None"],
                answer: 2,
                explanation: "They predict what you’ll like next based on patterns.",
              },
            ],
          },
        },
        {
          id: "m1l2",
          type: "video",
          title: "The Data Science Workflow",
          duration: "18 min",
          videoUrl: "https://www.youtube.com/embed/xm0wXPdY4c0",
          objectives: [
            "Describe the six stages of a DS project",
            "Understand iteration & feedback loops",
          ],
          reading: {
            title: "The Data Science Workflow (Infographic)",
            content:
              "Typical stages: Problem → Data → Cleaning → EDA → Modeling → Deployment & Monitoring. Expect to iterate as new insights appear.",
          },
          quiz: {
            passing: 70,
            questions: [
              {
                q: "Which stage handles missing values?",
                options: ["Problem definition", "Data cleaning", "EDA", "Deployment"],
                answer: 1,
                explanation: "Cleaning fixes missing/duplicate/inconsistent data.",
              },
              {
                q: "The DS workflow is strictly linear.",
                options: ["True", "False"],
                answer: 1,
                explanation: "It’s iterative; you often loop back.",
              },
            ],
          },
          assignment: {
            title: "Map a Data Science Project",
            brief:
              "Choose a real problem (e.g., churn prediction). Outline: 1) problem, 2) needed data, 3) sources, 4) challenges. Submit a PDF.",
            rubric: [
              { name: "Clarity of problem", weight: 25 },
              { name: "Feasible data sources", weight: 25 },
              { name: "Workflow understanding", weight: 30 },
              { name: "Presentation quality", weight: 20 },
            ],
          },
        },
      ],
    },
    {
      id: "m2",
      title: "Python for Data Science",
      effort: "~6 hours",
      lessons: [
        {
          id: "m2l1",
          type: "reading",
          title: "Python Basics: Types, Loops, Functions",
          duration: "35 min",
          objectives: [
            "Write simple Python programs",
            "Use lists, dicts, loops, and functions",
          ],
          reading: {
            title: "Quickstart Guide",
            content:
              "Open a notebook (Jupyter/Colab). Practice variables, loops, and functions. Try katas: reverse a string; compute factorial; fizzbuzz.",
          },
          quiz: {
            passing: 70,
            questions: [
              {
                q: "Which creates a list in Python?",
                options: ["{}", "[]", "()", "<>"],
                answer: 1,
                explanation: "Square brackets make lists.",
              },
            ],
          },
        },
        {
          id: "m2l2",
          type: "video",
          title: "Pandas, NumPy & Matplotlib Basics",
          duration: "22 min",
          videoUrl: "https://www.youtube.com/embed/vmEHCJofslg",
          objectives: [
            "Load CSV, summarize, and visualize",
            "Select/filter data with pandas",
          ],
          reading: {
            title: "Cheat Sheets",
            content:
              "Pandas: read_csv, head, describe, loc/iloc; NumPy arrays; Matplotlib plots.",
          },
        },
      ],
    },
    {
      id: "m6",
      title: "Capstone: Customer Churn Prediction",
      effort: "~8 hours",
      lessons: [
        {
          id: "m6l1",
          type: "reading",
          title: "Project Brief & Dataset",
          duration: "15 min",
          reading: {
            title: "Capstone Overview",
            content:
              "Predict telecom customer churn. Deliver: notebook, visual report, 3‑minute video. Evaluation: accuracy + clarity.",
          },
        },
      ],
    },
  ],
};

const STORAGE_KEY = `course-progress-${course.id}`;

function useProgress() {
  const [progress, setProgress] = useState(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : { completed: {}, quizScores: {} };
    } catch {
      return { completed: {}, quizScores: {} };
    }
  });
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  }, [progress]);

  const markComplete = (lessonId) =>
    setProgress((p) => ({ ...p, completed: { ...p.completed, [lessonId]: true } }));

  const saveQuizScore = (lessonId, scorePercent) =>
    setProgress((p) => ({ ...p, quizScores: { ...p.quizScores, [lessonId]: scorePercent } }));

  const overall = useMemo(() => {
    const lessonIds = course.modules.flatMap((m) => m.lessons.map((l) => l.id));
    const done = lessonIds.filter((id) => progress.completed[id]).length;
    return Math.round((done / Math.max(lessonIds.length, 1)) * 100);
  }, [progress]);

  return { progress, markComplete, saveQuizScore, overall };
}

function YouTube({ url }) {
  if (!url) return null;
  return (
    <div className="aspect-video w-full overflow-hidden rounded-2xl shadow">
      <iframe
        className="h-full w-full"
        src={url}
        title="Lesson video"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowFullScreen
      />
    </div>
  );
}

function ProgressBar({ value }) {
  return (
    <div className="progress" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={value}>
      <div style={{ width: `${value}%` }}></div>
    </div>
  );
}

function Quiz({ lesson, onPassed, saveScore, storedScore }) {
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const questions = lesson.quiz?.questions || [];

  const score = useMemo(() => {
    let correct = 0;
    questions.forEach((q, i) => {
      if (answers[i] === q.answer) correct++;
    });
    return Math.round((correct / Math.max(questions.length, 1)) * 100);
  }, [answers, questions]);

  useEffect(() => {
    if (submitted) {
      saveScore(lesson.id, score);
      if (score >= (lesson.quiz?.passing ?? 70)) onPassed?.();
    }
  }, [submitted]);

  if (!lesson.quiz) return null;

  return (
    <div className="card mt-6">
      <div className="card-header">
        <div className="card-title">Knowledge Check</div>
      </div>
      <div className="card-content">
        {questions.map((q, i) => (
          <div key={i} className="mb-6">
            <p className="font-medium">Q{i + 1}. {q.q}</p>
            <div className="mt-2 grid gap-2">
              {q.options.map((opt, idx) => (
                <label key={idx} className="flex items-center gap-2 rounded-xl border p-3">
                  <input
                    type="radio"
                    name={`q-${i}`}
                    className="h-4 w-4"
                    checked={answers[i] === idx}
                    onChange={() => setAnswers({ ...answers, [i]: idx })}
                  />
                  <span>{opt}</span>
                </label>
              ))}
            </div>
            {submitted && (
              <div className="mt-2 text-sm">
                {answers[i] === q.answer ? (
                  <div className="text-green-600">Correct. {q.explanation}</div>
                ) : (
                  <div className="text-red-600">Not quite. {q.explanation}</div>
                )}
              </div>
            )}
          </div>
        ))}

        <div className="flex items-center justify-between rounded-2xl bg-gray-50 p-4">
          <div className="text-sm">
            <div className="font-semibold">Score: {submitted ? score : (storedScore ?? 0)}%</div>
            <div>Passing: {lesson.quiz?.passing ?? 70}%</div>
          </div>
          <div className="flex gap-2">
            <button className="btn" onClick={() => { setAnswers({}); setSubmitted(false); }}>Reset</button>
            <button className="btn btn-primary" onClick={() => setSubmitted(true)}>Submit</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const { progress, markComplete, saveQuizScore, overall } = useProgress();
  const [view, setView] = useState({ page: "home", moduleId: null, lessonId: null });
  const currentModule = course.modules.find((m) => m.id === view.moduleId);
  const currentLesson = currentModule?.lessons.find((l) => l.id === view.lessonId);

  return (
    <div className="container py-6">
      <Header setView={setView} overall={overall} />
      {view.page === "home" && (
        <>
          <Hero overall={overall} />
          <Syllabus
            goToLesson={(mId, lId) => setView({ page: "lesson", moduleId: mId, lessonId: lId })}
            progress={progress}
          />
        </>
      )}
      {view.page === "lesson" && currentLesson && (
        <LessonView
          module={currentModule}
          lesson={currentLesson}
          progress={progress}
          onBack={() => setView({ page: "home", moduleId: null, lessonId: null })}
          onComplete={() => markComplete(currentLesson.id)}
          saveQuizScore={saveQuizScore}
        />
      )}
      <Footer />
    </div>
  );
}

function Header({ setView, overall }) {
  return (
    <div className="mb-6 flex items-center justify-between">
      <div>
        <div className="text-xl font-bold">{course.title}</div>
        <div className="text-sm text-gray-500">{course.subtitle}</div>
      </div>
      <div className="flex items-center gap-3">
        <div className="w-40"><ProgressBar value={overall} /></div>
        <span className="badge">{overall}% complete</span>
        <button className="btn" onClick={() => setView({ page: "home", moduleId: null, lessonId: null })}>
          Home
        </button>
      </div>
    </div>
  );
}

function Hero({ overall }) {
  return (
    <div className="card mb-8">
      <div className="card-content grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2">
          <h1 className="mb-2 text-2xl font-bold">{course.title}</h1>
          <p className="text-gray-600">{course.subtitle}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <span className="badge">{course.estimatedEffort}</span>
            <span className="badge">Instructor: {course.instructor.name}</span>
          </div>
          <div className="mt-6">
            <h3 className="mb-2 font-semibold">You will learn to:</h3>
            <ul className="grid list-disc gap-2 pl-6 text-sm">
              {course.outcomes.map((o, i) => <li key={i}>{o}</li>)}
            </ul>
          </div>
        </div>
        <div>
          <div className="rounded-2xl border p-4 bg-white">
            <div className="mb-2 text-sm font-semibold">Your Progress</div>
            <ProgressBar value={overall} />
            <div className="mt-2 text-sm text-gray-500">Complete lessons and pass quizzes to earn the certificate.</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Syllabus({ goToLesson, progress }) {
  return (
    <div className="space-y-6">
      {course.modules.map((m, mi) => (
        <div key={m.id} className="card">
          <div className="card-header">
            <div className="card-title flex items-center justify-between">
              <span>Module {mi + 1}: {m.title}</span>
              <span className="small">{m.effort}</span>
            </div>
          </div>
          <div className="card-content">
            <ul className="divide-y">
              {m.lessons.map((l, li) => {
                const done = !!progress.completed[l.id];
                return (
                  <li key={l.id} className="list-row">
                    <div className="row-left">
                      <div className={`h-3 w-3 rounded-full ${done ? "bg-green-500" : "bg-gray-300"}`}></div>
                      <div className="min-w-0">
                        <div className="truncate font-medium">Lesson {mi + 1}.{li + 1} — {l.title}</div>
                        <div className="small">{l.duration || "Self‑paced"}</div>
                      </div>
                    </div>
                    <button className="btn btn-primary" onClick={() => goToLesson(m.id, l.id)}>
                      Open
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      ))}
    </div>
  );
}

function LessonView({ module, lesson, onBack, onComplete, saveQuizScore, progress }) {
  const storedScore = progress.quizScores[lesson.id];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-sm text-gray-500">Module: {module.title}</div>
          <h2 className="text-xl font-bold">{lesson.title}</h2>
        </div>
        <div className="flex gap-2">
          <button className="btn" onClick={onBack}>Back to syllabus</button>
          <button className="btn btn-primary" onClick={onComplete}>Mark complete</button>
        </div>
      </div>

      {lesson.videoUrl && <YouTube url={lesson.videoUrl} />}

      {lesson.objectives?.length ? (
        <div className="rounded-2xl border p-4 bg-white">
          <div className="mb-2 text-sm font-semibold">Learning Objectives</div>
          <ul className="grid list-disc gap-2 pl-6 text-sm">
            {lesson.objectives.map((o, i) => <li key={i}>{o}</li>)}
          </ul>
        </div>
      ) : null}

      {lesson.reading && (
        <div className="card">
          <div className="card-header">
            <div className="card-title">{lesson.reading.title}</div>
          </div>
          <div className="card-content">
            <p className="text-sm leading-relaxed text-gray-600">{lesson.reading.content}</p>
            {lesson.reading.resources?.length ? (
              <div className="mt-3 text-sm">
                <div className="mb-1 font-semibold">Resources</div>
                <ul className="list-disc pl-6">
                  {lesson.reading.resources.map((r, i) => (
                    <li key={i}><a className="underline" href={r.url} target="_blank" rel="noreferrer">{r.label}</a></li>
                  ))}
                </ul>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {lesson.discussionPrompt && (
        <div className="card">
          <div className="card-header">
            <div className="card-title">Discussion</div>
          </div>
          <div className="card-content">
            <p className="text-sm mb-3">{lesson.discussionPrompt}</p>
            <input className="w-full rounded-xl border p-3" placeholder="Write your thoughts (saved in this page only)..." />
          </div>
        </div>
      )}

      <Quiz
        lesson={lesson}
        onPassed={onComplete}
        saveScore={saveQuizScore}
        storedScore={storedScore}
      />

      {lesson.assignment && (
        <div className="card mt-6">
          <div className="card-header">
            <div className="card-title">Graded Assignment: {lesson.assignment.title}</div>
          </div>
          <div className="card-content">
            <p className="text-sm text-gray-600">{lesson.assignment.brief}</p>
            <div className="mt-4">
              <div className="mb-2 text-sm font-semibold">Rubric</div>
              <ul className="list-disc pl-6 text-sm">
                {lesson.assignment.rubric.map((r, i) => (
                  <li key={i}>{r.name} — {r.weight}%</li>
                ))}
              </ul>
            </div>
            <div className="mt-4 flex gap-2">
              <button className="btn">Upload PDF (placeholder)</button>
              <a className="btn" href="https://docs.google.com/document/u/0/" target="_blank" rel="noreferrer">Open Google Docs</a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Footer() {
  return (
    <div className="mt-10 border-t pt-6 text-center text-xs text-gray-500">
      © {new Date().getFullYear()} • {course.title}. Built with React + Tailwind.
    </div>
  );
}
