Smart To-Do — Local Demo
-----------------------

Files:
- index.html : single-file to-do web app. Open in a browser (double-click) to run locally.

Features:
- Add / edit / delete tasks
- Mark complete, filter, export JSON
- Local "AI suggestions" (heuristic) that can be replaced by real AI calls
- Persists tasks in browser localStorage

To deploy publicly:
- Upload index.html to GitHub Pages (create a repo and upload file), or drop into any static hosting (Netlify, Vercel).
- To wire to OpenAI or another AI provider, you'd add a small server endpoint that calls the provider and returns suggestions to the client.
  Example (Node/Express pseudo):
    POST /api/suggest { prompt }
    // server makes OpenAI call and returns suggestions

I cannot deploy to a public URL from this environment. If you'd like, I can:
- Provide the exact Node/Express + Netlify/Vercel steps to deploy.
- Or show the code to connect suggestions to OpenAI (you'll need your own API key).
